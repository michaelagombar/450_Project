package xml;
 
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class xmlreader {

    public static void main(String[] args) {

        try {
            String fileName = "facMgr.xml";

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            File xml = new File(fileName);
            if (!xml.exists()) {
                System.err.println("**** XML File '" + fileName + "' cannot be found");
                System.exit(-1);
            }

            Document doc = db.parse(xml);
            doc.getDocumentElement().normalize();

            NodeList facInfo = doc.getDocumentElement().getChildNodes();

            for (int i = 0; i < facInfo.getLength(); i++) {
                if (facInfo.item(i).getNodeType() == Node.TEXT_NODE) {
                    continue;
                }
                
                String entryName = facInfo.item(i).getNodeName();
                if (!entryName.equals("Name")) {
                    System.err.println("Unexpected node found: " + entryName);
                    return;
                }
                
                // Get a node attribute
                NamedNodeMap aMap = facInfo.item(i).getAttributes();
                String facId = aMap.getNamedItem("Id").getNodeValue();

                // Get a named nodes
                Element elem = (Element) facInfo.item(i);
                String facName = elem.getElementsByTagName("Name").item(0).getTextContent();
                String facRate = elem.getElementsByTagName("Rate").item(0).getTextContent();
                String facRTD = elem.getElementsByTagName("rtd").item(0).getTextContent();
                String facLinks = elem.getElementsByTagName("Links").item(0).getTextContent();
                String facItem = elem.getElementsByTagName("Item").item(0).getTextContent();

                // Get all nodes named "LINK" - there can be 0 or more
                ArrayList<String> linkDescriptions = new ArrayList<>();
                NodeList linkList = elem.getElementsByTagName("Links");
                for (int j = 0; j < linkList.getLength(); j++) {
                    if (linkList.item(j).getNodeType() == Node.TEXT_NODE) {
                        continue;
                    }

                    entryName = linkList.item(j).getNodeName();
                    if (!entryName.equals("Links")) {
                        System.err.println("Unexpected node found: " + entryName);
                        return;
                    }

                    // Get some named nodes from links
                    elem = (Element) linkList.item(j);
                    String linkCity = elem.getElementsByTagName("City").item(0).getTextContent();
                    String linkDistance = elem.getElementsByTagName("Distance").item(0).getTextContent();
                    // Create a string summary of the book
                    linkDescriptions.add("City name: " + linkCity + "| Distance: " + linkDistance);// + ", " + bookDate + " [" + bookIsbn13 + "]");
                }
                // get all nodes names "ITEM"
                ArrayList<String> itemDescription = new ArrayList<>();
                NodeList itemList = elem.getElementsByTagName("Item");
                for (int j = 0; j < itemList.getLength(); j++) {
                    if (itemList.item(j).getNodeType() == Node.TEXT_NODE) {
                        continue;
                    }

                    entryName = itemList.item(j).getNodeName();
                    if (!entryName.equals("Item")) {
                        System.err.println("Unexpected node found: " + entryName);
                        return;
                    }

                    // Get some named nodes from Item
                    elem = (Element) itemList.item(j);
                    String itemID = elem.getElementsByTagName("City").item(0).getTextContent();
                    String itemQty = elem.getElementsByTagName("Distance").item(0).getTextContent();
                    // Create a string summary of the book
                    itemDescription.add("ID of Item: " + itemID + ", amount of item: " + itemQty);
                }

                // Here I would create a Store object using the data I just loaded from the XML
                System.out.println("Facility: " + facName + " [rate: #" + facRate + facRTD + "], "  + facLinks + facItem + "\n" + linkDescriptions + itemDescription +"\n");
                
            }

        } catch (ParserConfigurationException | SAXException | IOException | DOMException e) {
            e.printStackTrace();
        }
    }

}